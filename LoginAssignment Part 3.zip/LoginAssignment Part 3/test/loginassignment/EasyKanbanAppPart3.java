/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginassignment;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class EasyKanbanAppPart3 {
    private EasyKanbanApp app;

    @BeforeEach
    public void setUp() {
        app = new EasyKanbanApp();

        // Add test data
        Task task1 = new Task("Create Login", "Create a login module", "Mike Smith", 5, "To Do");
        Task task2 = new Task("Create Add Features", "Create add features module", "Edward Harrison", 8, "Doing");
        Task task3 = new Task("Create Reports", "Create reports module", "Samantha Paulson", 2, "Done");
        Task task4 = new Task("Add Arrays", "Add arrays to the project", "Glenda Oberholzer", 11, "To Do");

        app.addTask(task1);
        app.addTask(task2);
        app.addTask(task3);
        app.addTask(task4);
    }

    @Test
    public void testDeveloperArrayPopulated() {
        ArrayList<String> developers = new ArrayList<>();
        developers.add("Mike Smith");
        developers.add("Edward Harrison");
        developers.add("Samantha Paulson");
        developers.add("Glenda Oberholzer");

        assertEquals(developers, app.getDevelopers());
    }

    @Test
    public void testDisplayLongestDurationTask() {
        String expected = "Task with the longest duration:\nDeveloper: Glenda Oberholzer, Duration: 11.0 hours";
        assertEquals(expected, app.getLongestDurationTask());
    }

    @Test
    public void testSearchTaskByName() {
        String expected = "Task Details: \nTask Name: Create Login\nDeveloper: Mike Smith\nTask Status: To Do";
        assertEquals(expected, app.searchTaskByName("Create Login"));
    }

    @Test
    public void testSearchTasksByDeveloper() {
        String expected = "Tasks assigned to Samantha Paulson:\nTask Name: Create Reports, Task Status: Done\n";
        assertEquals(expected, app.searchTasksByDeveloper("Samantha Paulson"));
    }

    @Test
    public void testDeleteTaskByName() {
        assertTrue(app.deleteTaskByName("Create Reports"));
        assertEquals("Task not found", app.searchTaskByName("Create Reports"));
    }
}
