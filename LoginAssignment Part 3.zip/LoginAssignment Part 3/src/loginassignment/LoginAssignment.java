/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loginassignment;

import javax.swing.JOptionPane;

/**
 * Main class for the LoginAssignment program.
 */
public class LoginAssignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        LoginRegister loginregister = new LoginRegister();

        boolean running = true;
        while (running) {
            String[] options = {"Register", "Login", "Cancel"};
            int choice = JOptionPane.showOptionDialog(null, "Choose an option:", "Login/Register System",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            if (choice == 0) { // Register
                registerUser(loginregister);
            } else if (choice == 1) { // Login
                boolean loggedIn = loginUser(loginregister);
                if (loggedIn) {
                    JOptionPane.showMessageDialog(null, "Welcome " + loginregister.getFirstName() + " " + loginregister.getLastName()
                            + ", it is great to see you.");
                    EasyKanbanApp kanbanApp = new EasyKanbanApp();
                    manageKanbanApp(kanbanApp);
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password.");
                }
                String loginStatus = loginregister.returnLoginStatus();
                JOptionPane.showMessageDialog(null, "Login Status: " + loginStatus);
            } else if (choice == 2) { // Cancel
                running = false;
            }
        }
    }

    public static void registerUser(LoginRegister register) {
        String firstname = JOptionPane.showInputDialog(null, "Enter first name: ");
        register.setFirstName(firstname);
        String lastName = JOptionPane.showInputDialog(null, "Enter last name: ");
        register.setLastName(lastName);

        boolean isValidUsername = false;
        while (!isValidUsername) {
            // input
            String username = JOptionPane.showInputDialog(null, "Enter username:");
            // testing if valid
            isValidUsername = register.checkUsername(username);
            if (!isValidUsername) {
                JOptionPane.showMessageDialog(null, "Invalid username format. Please try again.");
            } else {
                // setting
                register.setUsername(username);
            }
        }

        boolean isValidPassword = false;
        while (!isValidPassword) {
            String password = JOptionPane.showInputDialog(null, "Enter password:");
            isValidPassword = register.checkPasswordComplexity(password);
            if (!isValidPassword) {
                JOptionPane.showMessageDialog(null, "Password is not correctly formatted,"
                        + " please ensure that the password contains at least 8 characters, "
                        + "a capital letter, a number, and a special character");
            } else {
                register.setPassword(password); // Set the password after validation
            }
        }
        JOptionPane.showMessageDialog(null, "User registered successfully!");
    }

    public static boolean loginUser(LoginRegister register) {
        String username = JOptionPane.showInputDialog(null, "Enter username:");
        String password = JOptionPane.showInputDialog(null, "Enter password:");

        return register.checkLogin(username, password);
    }

    public static void manageKanbanApp(EasyKanbanApp kanbanApp) {
        boolean running = true;

        while (running) {
            String[] options = {"Add Task", "Display Tasks by Status", "Display Longest Duration Task",
                    "Search Task by Name", "Search Tasks by Developer", "Delete Task by Name", "Display All Tasks", "Quit"};
            String choice = (String) JOptionPane.showInputDialog(null, "Choose an option:", "EasyKanban",
                    JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            if ("Add Task".equals(choice)) {
                Task task = new Task();
                task.setTaskName(JOptionPane.showInputDialog("Enter Task Name:"));
                task.setTaskDescription(JOptionPane.showInputDialog("Enter Task Description:"));
                task.setDeveloperDetails(JOptionPane.showInputDialog("Enter Developer Details:"));
                task.setTaskDuration(Double.parseDouble(JOptionPane.showInputDialog("Enter Task Duration (hours):")));
                task.setTaskStatus(JOptionPane.showInputDialog("Select Task Status: To Do, Done, or Doing"));

                if (task.checkTaskDescription()) {
                    kanbanApp.addTask(task);
                    JOptionPane.showMessageDialog(null, "Task successfully captured:\n" + task.printTaskDetails());
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
                }
            } else if ("Display Tasks by Status".equals(choice)) {
                String status = JOptionPane.showInputDialog("Enter Task Status to display (To Do, Done, or Doing):");
                kanbanApp.displayTasksByStatus(status);
            } else if ("Display Longest Duration Task".equals(choice)) {
                JOptionPane.showMessageDialog(null, kanbanApp.getLongestDurationTask());
            } else if ("Search Task by Name".equals(choice)) {
                String taskName = JOptionPane.showInputDialog("Enter Task Name to search:");
                JOptionPane.showMessageDialog(null, kanbanApp.searchTaskByName(taskName));
            } else if ("Search Tasks by Developer".equals(choice)) {
                String developerName = JOptionPane.showInputDialog("Enter Developer Name to search:");
                JOptionPane.showMessageDialog(null, kanbanApp.searchTasksByDeveloper(developerName));
            } else if ("Delete Task by Name".equals(choice)) {
                String taskName = JOptionPane.showInputDialog("Enter Task Name to delete:");
                boolean deleted = kanbanApp.deleteTaskByName(taskName);
                if (deleted) {
                    JOptionPane.showMessageDialog(null, "Task deleted successfully.");
                } else {
                    JOptionPane.showMessageDialog(null, "Task not found.");
                }
            } else if ("Display All Tasks".equals(choice)) {
                kanbanApp.displayAllTasks();
            } else if ("Quit".equals(choice)) {
                running = false;
            }
        }
    }
}
