/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginassignment;

import javax.swing.*;
import java.util.ArrayList;

/**
 * Class representing the EasyKanban application.
 */
public class EasyKanbanApp {

    private ArrayList<Task> tasks = new ArrayList<>();
    private ArrayList<String> developers = new ArrayList<>();
    private ArrayList<String> taskNames = new ArrayList<>();
    private ArrayList<String> taskIDs = new ArrayList<>();
    private ArrayList<Double> taskDurations = new ArrayList<>();
    private ArrayList<String> taskStatuses = new ArrayList<>();

    public EasyKanbanApp() {
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");

        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks:"));

        for (int i = 0; i < numTasks; i++) {
            Task task = new Task();
            task.setTaskName(JOptionPane.showInputDialog("Enter Task Name:"));
            task.setTaskDescription(JOptionPane.showInputDialog("Enter Task Description:"));
            task.setDeveloperDetails(JOptionPane.showInputDialog("Enter Developer Details:"));
            task.setTaskDuration(Double.parseDouble(JOptionPane.showInputDialog("Enter Task Duration (hours):")));
            task.setTaskStatus(JOptionPane.showInputDialog("Select Task Status: To Do, Done, or Doing"));

            if (task.checkTaskDescription()) {
                addTask(task);
                JOptionPane.showMessageDialog(null, "Task successfully captured:\n" + task.printTaskDetails());
            } else {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
                i--; // Decrement i to re-enter the task details
            }
        }

        double totalHours = 0;
        StringBuilder allTasksDetails = new StringBuilder("All Tasks Details:\n");
        for (Task task : tasks) {
            allTasksDetails.append(task.printTaskDetails()).append("\n");
            totalHours += task.getTaskDuration();
        }

        JOptionPane.showMessageDialog(null, "Total Hours: " + totalHours);
        JOptionPane.showMessageDialog(null, allTasksDetails.toString());
    }

    public ArrayList<String> getDevelopers() {
        return developers;
    }

    public void addTask(Task task) {
        tasks.add(task);
        developers.add(task.getDeveloperDetails());
        taskNames.add(task.getTaskName());
        taskIDs.add(task.createTaskID());
        taskDurations.add(task.getTaskDuration());
        taskStatuses.add(task.getTaskStatus());
    }

    public void displayTasksByStatus(String status) {
        StringBuilder result = new StringBuilder();
        for (Task task : tasks) {
            if (task.getTaskStatus().equalsIgnoreCase(status)) {
                result.append(task.printTaskDetails()).append("\n");
            }
        }
        JOptionPane.showMessageDialog(null, result.toString());
    }

    public String getLongestDurationTask() {
        Task longestTask = null;
        for (Task task : tasks) {
            if (longestTask == null || task.getTaskDuration() > longestTask.getTaskDuration()) {
                longestTask = task;
            }
        }
        if (longestTask != null) {
            return "Task with the longest duration:\n" + longestTask.printTaskDetails();
        } else {
            return "No tasks available.";
        }
    }

    public String searchTaskByName(String name) {
        for (Task task : tasks) {
            if (task.getTaskName().equalsIgnoreCase(name)) {
                return "Task Found:\n" + task.printTaskDetails();
            }
        }
        return "Task not found";
    }

    public String searchTasksByDeveloper(String developer) {
        StringBuilder result = new StringBuilder();
        for (Task task : tasks) {
            if (task.getDeveloperDetails().equalsIgnoreCase(developer)) {
                result.append("Task Name: ").append(task.getTaskName())
                        .append(", Task Status: ").append(task.getTaskStatus()).append("\n");
            }
        }
        return result.toString();
    }

    public boolean deleteTaskByName(String name) {
        for (Task task : tasks) {
            if (task.getTaskName().equalsIgnoreCase(name)) {
                tasks.remove(task);
                return true;
            }
        }
        return false;
    }

    public void displayAllTasks() {
        StringBuilder result = new StringBuilder("All Tasks:\n");
        for (Task task : tasks) {
            result.append(task.printTaskDetails()).append("\n");
        }
        JOptionPane.showMessageDialog(null, result.toString());
    }
}

