/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loginassignment;

/**
 *
 * @author sihle
 */
public class ReferenceListPart3 {
    //    Farrell, J. (2019). JavaTM Programming, Tenth Edition. Course Technology, Cengage Learning.Accessed 07 June 2024
// Stack Overflow." Stack Overflow, 20 March 2016. https://stackoverflow.com/. Accessed 12 June 2024
}
